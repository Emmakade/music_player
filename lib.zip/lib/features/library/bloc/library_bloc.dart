import 'package:flutter_bloc/flutter_bloc.dart';
import 'library_event.dart';
import 'library_state.dart';
import '../repository/library_repository.dart';

class LibraryBloc extends Bloc<LibraryEvent, LibraryState> {
  final LibraryRepository repository;

  LibraryBloc({required this.repository}) : super(LibraryInitial()) {
    on<CheckPermissionEvent>(_onCheckPermission);
    on<RequestPermissionEvent>(_onRequestPermission);
    on<LoadLibraryEvent>(_onLoadLibrary);
  }

  Future<void> _onCheckPermission(
    CheckPermissionEvent event,
    Emitter<LibraryState> emit,
  ) async {
    final granted = await repository.checkPermission();
    if (granted) {
      add(LoadLibraryEvent());
    } else {
      emit(LibraryPermissionDenied());
    }
  }

  Future<void> _onRequestPermission(
    RequestPermissionEvent event,
    Emitter<LibraryState> emit,
  ) async {
    final granted = await repository.requestPermission();
    if (granted) {
      add(LoadLibraryEvent());
    } else {
      emit(LibraryPermissionDenied());
    }
  }

  Future<void> _onLoadLibrary(
    LoadLibraryEvent event,
    Emitter<LibraryState> emit,
  ) async {
    emit(LibraryLoading());
    try {
      final tracks = await repository.fetchTracks();
      emit(LibraryLoaded(tracks: tracks));
    } catch (e) {
      emit(LibraryError(message: e.toString()));
    }
  }
}
