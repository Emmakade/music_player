part of 'player_bloc.dart';

abstract class PlayerEvent {}

class PlayTrack extends PlayerEvent {
  final Track track;
  PlayTrack(this.track);
}

class PauseTrack extends PlayerEvent {}

class ResumeTrack extends PlayerEvent {}

class StopTrack extends PlayerEvent {}

class SeekTrack extends PlayerEvent {
  final Duration position;
  SeekTrack(this.position);
}

// New events for previous and next track
class PreviuosTrack extends PlayerEvent {}

class NextTrack extends PlayerEvent {}

class SetQueue extends PlayerEvent {
  final List<Track> tracks;
  final int initialIndex;
  SetQueue(this.tracks, this.initialIndex);
}
