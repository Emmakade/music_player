part of 'player_bloc.dart';

abstract class PlayerState {}

class PlayerInitial extends PlayerState {}

class PlayerReady extends PlayerState {
  final Track track;
  final bool isPlaying;

  PlayerReady(this.track, {this.isPlaying = true});
}

class PlayerPlaying extends PlayerState {
  final Track track;
  final Duration position;
  final Duration duration;
  PlayerPlaying(this.track, this.position, this.duration);
}

class PlayerPaused extends PlayerState {
  final Track track;
  final Duration position;
  final Duration duration;
  PlayerPaused(this.track, this.position, this.duration);
}

class PlayerStopped extends PlayerState {}

class PlayerError extends PlayerState {
  final String message;
  PlayerError(this.message);
}
