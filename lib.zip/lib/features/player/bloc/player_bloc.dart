import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:just_audio/just_audio.dart';
import '../../../core/models/track.dart';

part 'player_event.dart';
part 'player_state.dart';

class PlayerBloc extends Bloc<PlayerEvent, PlayerState> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  late List<Track> _queue;
  late int _currentIndex;

  PlayerBloc() : super(PlayerInitial()) {
    _queue = [];
    _currentIndex = -1;

    on<PlayTrack>(_onPlayTrack);
    on<PauseTrack>(_onPauseTrack);
    on<ResumeTrack>(_onResumeTrack);
    on<SeekTrack>(_onSeekTrack);
    on<_UpdatePosition>(_onUpdatePosition);
    on<PreviuosTrack>(_onPreviousTrack);
    on<NextTrack>(_onNextTrack);
    on<SetQueue>(_onSetQueue);

    // Listen to position & duration updates
    _audioPlayer.positionStream.listen((pos) {
      try {
        final track = _currentTrack;
        if (track != null) {
          final duration = _audioPlayer.duration ?? Duration.zero;
          if (_audioPlayer.playing) {
            add(_UpdatePosition(track, pos, duration));
          }
        }
      } catch (e) {
        // Handle any errors in position stream
        print("Error in position stream: $e");
      }
    });

    // Listen to completion to automatically play next track
    _audioPlayer.playerStateStream.listen((state) {
      try {
        if (state.processingState == ProcessingState.completed) {
          add(NextTrack());
        }
      } catch (e) {
        // Handle any errors in player state stream
        print("Error in player state stream: $e");
      }
    });
  }

  Track? get _currentTrack =>
      _currentIndex >= 0 && _currentIndex < _queue.length
      ? _queue[_currentIndex]
      : null;

  bool _isValidTrackPath(String path) {
    try {
      if (path.isEmpty) {
        print("Track path is empty");
        return false;
      }

      final file = File(path);
      final exists = file.existsSync();
      print("Checking file path: $path, exists: $exists");
      return exists;
    } catch (e) {
      print("Error checking file path $path: $e");
      return false;
    }
  }

  Future<void> _onPlayTrack(PlayTrack event, Emitter<PlayerState> emit) async {
    try {
      // Validate track path
      if (event.track.path.isEmpty) {
        emit(PlayerError("Track path is empty"));
        return;
      }

      // Check if file exists
      if (!_isValidTrackPath(event.track.path)) {
        emit(PlayerError("Audio file not found: ${event.track.path}"));
        return;
      }

      // Find the track in the queue, or add it if not found
      int trackIndex = _queue.indexWhere((track) => track.id == event.track.id);
      if (trackIndex == -1) {
        // Track not in queue, add it and set as current
        _queue.add(event.track);
        _currentIndex = _queue.length - 1;
      } else {
        _currentIndex = trackIndex;
      }

      await _audioPlayer.stop(); // Stop any current playback
      await _audioPlayer.setFilePath(event.track.path);
      await _audioPlayer.seek(Duration.zero); // Reset position to start
      await _audioPlayer.play();

      emit(
        PlayerPlaying(
          event.track,
          Duration.zero,
          _audioPlayer.duration ?? Duration.zero,
        ),
      );
    } catch (e) {
      print("PlayTrack error: $e");
      emit(PlayerError("Failed to play track: ${e.toString()}"));
    }
  }

  Future<void> _onPauseTrack(
    PauseTrack event,
    Emitter<PlayerState> emit,
  ) async {
    if (_currentTrack != null) {
      await _audioPlayer.pause();
      emit(
        PlayerPaused(
          _currentTrack!,
          _audioPlayer.position,
          _audioPlayer.duration ?? Duration.zero,
        ),
      );
    }
  }

  Future<void> _onResumeTrack(
    ResumeTrack event,
    Emitter<PlayerState> emit,
  ) async {
    if (_currentTrack != null) {
      await _audioPlayer.play();
      emit(
        PlayerPlaying(
          _currentTrack!,
          _audioPlayer.position,
          _audioPlayer.duration ?? Duration.zero,
        ),
      );
    }
  }

  Future<void> _onSeekTrack(SeekTrack event, Emitter<PlayerState> emit) async {
    await _audioPlayer.seek(event.position);
  }

  void _onUpdatePosition(_UpdatePosition event, Emitter<PlayerState> emit) {
    if (_audioPlayer.playing) {
      emit(PlayerPlaying(event.track, event.position, event.duration));
    } else {
      emit(PlayerPaused(event.track, event.position, event.duration));
    }
  }

  // Handlers for PreviousTrack and NextTrack events
  Future<void> _onPreviousTrack(
    PreviuosTrack event,
    Emitter<PlayerState> emit,
  ) async {
    try {
      if (_queue.isEmpty) {
        emit(PlayerError("No tracks in queue"));
        return;
      }

      if (_currentIndex > 0) {
        _currentIndex--;
      } else {
        // Loop back to last track
        _currentIndex = _queue.length - 1;
      }

      final previousTrack = _queue[_currentIndex];

      // Validate track path
      if (previousTrack.path.isEmpty) {
        emit(PlayerError("Previous track path is empty"));
        return;
      }

      if (!_isValidTrackPath(previousTrack.path)) {
        emit(
          PlayerError("Previous track file not found: ${previousTrack.path}"),
        );
        return;
      }

      await _audioPlayer.stop();
      await _audioPlayer.setFilePath(previousTrack.path);
      await _audioPlayer.seek(Duration.zero);
      await _audioPlayer.play();

      emit(
        PlayerPlaying(
          previousTrack,
          Duration.zero,
          _audioPlayer.duration ?? Duration.zero,
        ),
      );
    } catch (e) {
      print("PreviousTrack error: $e");
      emit(PlayerError("Failed to play previous track: ${e.toString()}"));
    }
  }

  Future<void> _onNextTrack(NextTrack event, Emitter<PlayerState> emit) async {
    try {
      if (_queue.isEmpty) {
        emit(PlayerError("No tracks in queue"));
        return;
      }

      if (_currentIndex < _queue.length - 1) {
        _currentIndex++;
      } else {
        // Loop back to first track
        _currentIndex = 0;
      }

      final nextTrack = _queue[_currentIndex];

      // Validate track path
      if (nextTrack.path.isEmpty) {
        emit(PlayerError("Next track path is empty"));
        return;
      }

      if (!_isValidTrackPath(nextTrack.path)) {
        emit(PlayerError("Next track file not found: ${nextTrack.path}"));
        return;
      }

      await _audioPlayer.stop();
      await _audioPlayer.setFilePath(nextTrack.path);
      await _audioPlayer.seek(Duration.zero);
      await _audioPlayer.play();

      emit(
        PlayerPlaying(
          nextTrack,
          Duration.zero,
          _audioPlayer.duration ?? Duration.zero,
        ),
      );
    } catch (e) {
      print("NextTrack error: $e");
      emit(PlayerError("Failed to play next track: ${e.toString()}"));
    }
  }

  Future<void> _onSetQueue(SetQueue event, Emitter<PlayerState> emit) async {
    try {
      if (event.tracks.isEmpty) {
        emit(PlayerError("Cannot set empty queue"));
        return;
      }

      _queue = List.from(event.tracks);
      _currentIndex = event.initialIndex;

      if (_currentIndex >= 0 && _currentIndex < _queue.length) {
        final track = _queue[_currentIndex];

        // Validate track path
        if (track.path.isEmpty) {
          emit(PlayerError("Queue track path is empty"));
          return;
        }

        if (!_isValidTrackPath(track.path)) {
          emit(PlayerError("Queue track file not found: ${track.path}"));
          return;
        }

        await _audioPlayer.stop();
        await _audioPlayer.setFilePath(track.path);
        await _audioPlayer.seek(Duration.zero);
        await _audioPlayer.play();

        emit(
          PlayerPlaying(
            track,
            Duration.zero,
            _audioPlayer.duration ?? Duration.zero,
          ),
        );
      } else {
        emit(PlayerError("Invalid initial index for queue"));
      }
    } catch (e) {
      print("SetQueue error: $e");
      emit(PlayerError("Failed to set queue: ${e.toString()}"));
    }
  }
}

// Internal event
class _UpdatePosition extends PlayerEvent {
  final Track track;
  final Duration position;
  final Duration duration;
  _UpdatePosition(this.track, this.position, this.duration);
}
