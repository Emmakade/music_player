import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:marquee/marquee.dart';
import 'package:music_player/core/models/track.dart';
import '../../../core/utils/format_duration.dart';
import '../../../core/utils/remove_file_extension.dart';
import '../../../shared/widgets/build_artwork.dart';
import '../bloc/player_bloc.dart';

class NowPlayingScreen extends StatefulWidget {
  final Track? track;
  final List<Track> tracks;
  const NowPlayingScreen({
    super.key,
    required this.track,
    required this.tracks,
  });

  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen> {
  bool _queueInitialized = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Now Playing'),
      ),
      body: BlocListener<PlayerBloc, PlayerState>(
        listener: (context, state) {
          // Set up the queue when the screen is first built (only once)
          if (!_queueInitialized &&
              widget.track != null &&
              widget.tracks.isNotEmpty) {
            final initialIndex = widget.tracks.indexWhere(
              (t) => t.id == widget.track!.id,
            );
            if (initialIndex != -1) {
              print(
                "Setting up queue with ${widget.tracks.length} tracks, initial index: $initialIndex",
              );
              print("Current track path: ${widget.track!.path}");
              context.read<PlayerBloc>().add(
                SetQueue(widget.tracks, initialIndex),
              );
              _queueInitialized = true;
            } else {
              print("Track not found in tracks list");
            }
          } else if (!_queueInitialized) {
            print("Track is null or tracks list is empty");
          }
        },
        child: BlocBuilder<PlayerBloc, PlayerState>(
          builder: (context, state) {
            Track? currentTrack = widget.track;
            if (state is PlayerPlaying) {
              currentTrack = state.track;
            } else if (state is PlayerPaused) {
              currentTrack = state.track;
            }

            if (state is PlayerError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error, size: 64, color: Colors.red),
                    const SizedBox(height: 16),
                    Text(
                      'Playback Error',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      state.message,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        if (currentTrack != null) {
                          context.read<PlayerBloc>().add(
                            PlayTrack(currentTrack),
                          );
                        }
                      },
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              );
            }

            final heroTag = 'artwork_${currentTrack!.id}';

            Duration position = Duration.zero;
            Duration duration = Duration.zero;
            if (state is PlayerPlaying) {
              position = state.position;
              duration = state.duration;
            } else if (state is PlayerPaused) {
              position = state.position;
              duration = state.duration;
            }

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Hero(
                    tag: heroTag,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: AspectRatio(
                        aspectRatio: 1,
                        child: buildArtwork(
                          currentTrack.artwork,
                          isCircular: false,
                          borderRadius: 0,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    height: 26,
                    child: Marquee(
                      text: removeFileExtension(currentTrack.title),
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                      crossAxisAlignment: CrossAxisAlignment.start,
                      blankSpace: 10.0,
                      velocity: 100.0,
                      pauseAfterRound: Duration(seconds: 2),
                      startPadding: 10.0,
                      accelerationDuration: Duration(seconds: 2),
                      accelerationCurve: Curves.linear,
                      decelerationDuration: Duration(milliseconds: 500),
                      decelerationCurve: Curves.easeOut,
                      startAfter: Duration(minutes: 1),
                    ),
                  ),
                  SizedBox(height: 10),

                  Text(
                    currentTrack.artist,
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 10),

                  Row(
                    children: [
                      Text(
                        formatDuration(position.inMilliseconds),
                        style: const TextStyle(color: Colors.white70),
                      ),
                      Expanded(
                        child: Slider(
                          value: duration.inSeconds > 0
                              ? position.inSeconds.toDouble()
                              : 0.0,
                          max: duration.inSeconds > 0
                              ? duration.inSeconds.toDouble()
                              : 1.0,
                          onChanged: duration.inSeconds > 0
                              ? (value) {
                                  context.read<PlayerBloc>().add(
                                    SeekTrack(Duration(seconds: value.toInt())),
                                  );
                                }
                              : null,
                        ),
                      ),

                      Text(
                        formatDuration(duration.inMilliseconds),
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.skip_previous, size: 28),
                        onPressed: () {
                          context.read<PlayerBloc>().add(PreviuosTrack());
                        },
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton.icon(
                        onPressed: () {
                          if (state is PlayerPlaying) {
                            context.read<PlayerBloc>().add(PauseTrack());
                          } else if (state is PlayerPaused) {
                            context.read<PlayerBloc>().add(ResumeTrack());
                          } else if (currentTrack != null) {
                            context.read<PlayerBloc>().add(
                              PlayTrack(currentTrack),
                            );
                          }
                        },
                        icon: Icon(
                          state is PlayerPlaying
                              ? Icons.pause
                              : Icons.play_arrow,
                        ),
                        label: Text(state is PlayerPlaying ? 'Pause' : 'Play'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      IconButton(
                        icon: const Icon(Icons.skip_next, size: 28),
                        onPressed: () {
                          context.read<PlayerBloc>().add(NextTrack());
                        },
                      ),
                    ],
                  ),

                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Up Next',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  const SizedBox(height: 8),

                  Expanded(
                    child: ListView.builder(
                      itemCount: widget.tracks.length,
                      itemBuilder: (context, index) {
                        final queueTrack = widget.tracks[index];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundImage:
                                queueTrack.artwork != null &&
                                    queueTrack.artwork!.isNotEmpty
                                ? NetworkImage(queueTrack.artwork!)
                                : null,
                            child:
                                queueTrack.artwork == null ||
                                    queueTrack.artwork!.isEmpty
                                ? const Icon(Icons.music_note)
                                : null,
                          ),
                          title: Text(removeFileExtension(queueTrack.title)),
                          subtitle: Text(queueTrack.artist),
                          onTap: () {
                            context.read<PlayerBloc>().add(
                              PlayTrack(queueTrack),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
