class RouteNames {
  static const String splash = '/';
  static const String library = '/library';
  static const String nowPlaying = '/now-playing';
  static const String musicList = '/music-list';
}
