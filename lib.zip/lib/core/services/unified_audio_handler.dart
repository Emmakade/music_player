import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';
import 'package:rxdart/rxdart.dart';
import 'package:flutter/foundation.dart'; // for debugPrint
import 'package:mediastore_audio/mediastore_audio.dart'; // your plugin

/// Convenience value for the seek bar.
class PositionData {
  final Duration position;
  final Duration bufferedPosition;
  final Duration? duration;
  const PositionData(this.position, this.bufferedPosition, this.duration);
}

class UnifiedAudioHandler extends BaseAudioHandler
    with QueueHandler, SeekHandler {
  // Core
  final _player = AudioPlayer();
  final _playlist = ConcatenatingAudioSource(children: []);

  // Device song cache from mediastore (you can shape to your model).
  final _deviceSongs = <MediaItem>[];

  // Rx subjects to expose UI-friendly streams.
  final _positionSubject = BehaviorSubject<PositionData>.seeded(
    const PositionData(Duration.zero, Duration.zero, null),
  );

  // Optional: Plug-in lyrics/equalizer hooks
  Future<String?> Function(MediaItem)? _lyricsProvider;
  // For equalizer, we only expose settings as state; implementation is plugin-specific.
  Map<String, dynamic> _eqSettings = {}; // e.g., {band0: +3, band1: -2}
  final _lyricsSubject = BehaviorSubject<String?>.seeded(null);
  final _eqSubject = BehaviorSubject<Map<String, dynamic>>.seeded({});

  UnifiedAudioHandler() {
    _init();
  }

  /// Optional: let app provide a lyrics resolver (ID3, LRC file, remote, etc.)
  void setLyricsProvider(Future<String?> Function(MediaItem) provider) {
    _lyricsProvider = provider;
    _maybeRefreshLyrics();
  }

  /// Optional: set equalizer params (your plugin applies them).
  Future<void> setEqualizerSettings(Map<String, dynamic> eq) async {
    _eqSettings = eq;
    _eqSubject.add(_eqSettings);
    // TODO: call your Android/iOS EQ bridge here.
  }

  Stream<PositionData> get positionDataStream => _positionSubject.stream;
  Stream<String?> get lyricsStream => _lyricsSubject.stream;
  Stream<Map<String, dynamic>> get equalizerStream => _eqSubject.stream;

  Future<void> _init() async {
    // 1) Configure audio session for music
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    // 2) Map player state -> system playback state
    _player.playbackEventStream.map(_transformEvent).pipe(playbackState);

    // 3) Wire current index -> currently playing MediaItem
    _player.currentIndexStream.listen(_broadcastMediaItem);

    // 4) When a track completes, auto-advance is handled by ConcatenatingAudioSource.
    //    Still, listen for ProcessingState.completed to broadcast "completed".
    _player.processingStateStream.listen((ps) async {
      if (ps == ProcessingState.completed) {
        // If you want auto-stop after end of playlist:
        // await stop(); // or loop/shuffle as desired
      }
    });

    // 5) Stream position for seek bar
    Rx.combineLatest3<Duration, Duration, Duration?, PositionData>(
      _player.positionStream,
      _player.bufferedPositionStream,
      _player.durationStream,
      (pos, buf, dur) => PositionData(pos, buf, dur),
    ).pipe(_positionSubject);

    // 6) Prefs: crossfade, gapless, preload
    _player.setAudioSource(_playlist);
    _player.setLoopMode(LoopMode.off);
    _player.setShuffleModeEnabled(false);
    _player.setVolume(1.0);
    _player.setSpeed(1.0);
    //_player.setCrossfadeDuration(const Duration(milliseconds: 250));
    //TODO: since '_player.setCrossfadeDuration' is not available in this
    //just_audio: ^0.10.4 plugin vesion, we will handle it manually
  }

  PlaybackState _transformEvent(PlaybackEvent e) {
    final processingState = () {
      switch (_player.processingState) {
        case ProcessingState.idle:
          return AudioProcessingState.idle;
        case ProcessingState.loading:
          return AudioProcessingState.loading;
        case ProcessingState.buffering:
          return AudioProcessingState.buffering;
        case ProcessingState.ready:
          return AudioProcessingState.ready;
        case ProcessingState.completed:
          return AudioProcessingState.completed;
      }
    }();

    return PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        _player.playing ? MediaControl.pause : MediaControl.play,
        MediaControl.stop,
        MediaControl.skipToNext,
      ],
      androidCompactActionIndices: const [0, 1, 3],
      systemActions: const {
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
        MediaAction.setShuffleMode,
        MediaAction.setRepeatMode,
        MediaAction.setSpeed,
      },
      processingState: processingState,
      playing: _player.playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
      queueIndex: _player.currentIndex,
    );
  }

  void _broadcastMediaItem(int? index) async {
    if (index == null || index < 0 || index >= queue.value.length) return;
    final item = queue.value[index];
    mediaItem.add(item);
    _maybeRefreshLyrics();
  }

  Future<void> _maybeRefreshLyrics() async {
    if (_lyricsProvider == null || mediaItem.value == null) {
      _lyricsSubject.add(null);
      return;
    }
    try {
      final l = await _lyricsProvider!(mediaItem.value!);
      _lyricsSubject.add(l);
    } catch (_) {
      _lyricsSubject.add(null);
    }
  }

  /// Build the queue from your mediastore plugin.
  /// You can provide filters (albumId, artistId, folder, etc.)
  Future<void> loadDeviceSongs({
    String? filter,
    bool includeArtwork = true,
  }) async {
    try {
      // Use your plugin API. Below is an example—adapt to your actual types.
      final songs = await MediastoreAudio.getAudios(
        // filter: filter,
        // includeArtwork: includeArtwork,
      );

      // Map to MediaItem list
      _deviceSongs
        ..clear()
        ..addAll(
          songs.map(
            (s) => MediaItem(
              id: s.uri, // must be a unique playable URI
              title: s.title ?? 'Unknown Title',
              album: s.album ?? 'Unknown Album',
              artist: s.artist ?? 'Unknown Artist',
              duration: s.duration != null
                  ? Duration(milliseconds: s.duration!)
                  : null,
              artUri: s.artworkUri != null ? Uri.parse(s.artworkUri!) : null,
              extras: {
                'albumId': s.albumId,
                'artistId': s.artistId,
                'track': s.track,
                'mimeType': s.mimeType,
                'size': s.size,
                // add anything you need for later (e.g., for EQ or lyrics)
              },
            ),
          ),
        );

      // Update queue + playlist
      await updateQueue(_deviceSongs);
    } catch (e) {
      debugPrint('Error loading songs: $e');
      rethrow;
    }
  }

  /// QueueHandler overrides
  @override
  Future<void> addQueueItem(MediaItem item) async {
    final newQueue = [...queue.value, item];
    queue.add(newQueue);
    await _playlist.add(AudioSource.uri(Uri.parse(item.id)));
  }

  @override
  Future<void> updateQueue(List<MediaItem> newQueue) async {
    queue.add(newQueue);
    await _playlist.clear();
    await _playlist.addAll(
      newQueue.map((m) => AudioSource.uri(Uri.parse(m.id))).toList(),
    );
  }

  @override
  Future<void> addQueueItems(List<MediaItem> mediaItems) async {
    final newQueue = [...queue.value, ...mediaItems];
    queue.add(newQueue);
    await _playlist.addAll(
      mediaItems.map((m) => AudioSource.uri(Uri.parse(m.id))).toList(),
    );
  }

  @override
  Future<void> removeQueueItem(MediaItem item) async {
    final idx = queue.value.indexWhere((m) => m.id == item.id);
    if (idx >= 0) {
      final newQueue = [...queue.value]..removeAt(idx);
      queue.add(newQueue);
      await _playlist.removeAt(idx);
    }
  }

  // Playback & transport controls
  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext() => _player.seekToNext();

  @override
  Future<void> skipToPrevious() => _player.seekToPrevious();

  @override
  Future<void> skipToQueueItem(int index) async {
    if (index < 0 || index >= queue.value.length) return;
    await _player.seek(Duration.zero, index: index);
    // optionally auto play
    if (!_player.playing) await _player.play();
  }

  // Shuffle / Repeat / Speed / Volume
  @override
  Future<void> setShuffleMode(AudioServiceShuffleMode shuffleMode) async {
    final enable = shuffleMode == AudioServiceShuffleMode.all;
    await _player.setShuffleModeEnabled(enable);
    playbackState.add(playbackState.value.copyWith(shuffleMode: shuffleMode));
  }

  @override
  Future<void> setRepeatMode(AudioServiceRepeatMode repeatMode) async {
    final mode = switch (repeatMode) {
      AudioServiceRepeatMode.none => LoopMode.off,
      AudioServiceRepeatMode.one => LoopMode.one,
      AudioServiceRepeatMode.all => LoopMode.all,
      _ => LoopMode.off,
    };
    await _player.setLoopMode(mode);
    playbackState.add(playbackState.value.copyWith(repeatMode: repeatMode));
  }

  @override
  Future<void> setSpeed(double speed) async {
    await _player.setSpeed(speed);
    playbackState.add(playbackState.value.copyWith(speed: speed));
  }

  Future<void> setVolume(double volume) async {
    await _player.setVolume(volume.clamp(0.0, 1.0));
  }

  @override
  Future<void> stop() async {
    await _player.stop();
    await _player.dispose();
    await _positionSubject.close();
    await _lyricsSubject.close();
    await _eqSubject.close();
    return super.stop();
  }
}
