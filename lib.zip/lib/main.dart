import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:hive_flutter/adapters.dart';

import 'core/route/app_routes.dart';
import 'core/route/route_names.dart';
import 'features/library/repository/library_repository.dart';
import 'features/library/bloc/library_bloc.dart';
import 'features/player/bloc/player_bloc.dart';
import 'shared/theme/theme.dart';
import 'package:audio_service/audio_service.dart';
import 'core/services/unified_audio_handler.dart';

late final UnifiedAudioHandler audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  audioHandler = await AudioService.init(
    builder: () => UnifiedAudioHandler(),
    config: AudioServiceConfig(
      androidNotificationChannelId: 'com.example.music_player.channel.audio',
      androidNotificationChannelName: 'Music Playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: false,
    ),
  );

  // Load songs via mediastore
  await audioHandler.loadDeviceSongs(includeArtwork: true);
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [RepositoryProvider(create: (_) => LibraryRepository())],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (ctx) =>
                LibraryBloc(repository: ctx.read<LibraryRepository>()),
          ),
          BlocProvider(create: (_) => PlayerBloc()),
          // add more blocs here if needed
        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Music Player',
          theme: appTheme,
          initialRoute: RouteNames.library,
          routes: appRoutes,
        ),
      ),
    );
  }
}
